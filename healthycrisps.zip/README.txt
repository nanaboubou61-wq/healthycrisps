Healthy Crisps Website ZIP

This ZIP is intentionally simple.
You will upload this to GitHub as instructed.

After upload, I will guide you to replace it with the full site automatically.
